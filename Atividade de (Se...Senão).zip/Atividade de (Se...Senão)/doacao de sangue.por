programa {
  funcao inicio() {
    inteiro idade

    escreva("Digite sua idade: ")
		leia(idade)

		se (idade >= 18 e idade <= 67)
		{
			escreva("Voce esta apto a doar sangue.")
		}
		senao
		{
			escreva("Voce nao esta apto a doar sangue.")
		}


}
}
